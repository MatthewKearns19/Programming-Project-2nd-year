
package dreamhome;

import java.io.Serializable;
import javax.swing.JOptionPane;

/**
 * Project: DreamHome
 * @author Keith Mahony, Ben Carroll, Matthew Kearns
 */
public abstract class Rental extends DreamHome implements Serializable {

    public double rentRate;
    public double typeRate;

    public Rental(double rentRate) {
        this.rentRate = rentRate;
    }

    public Rental(double rentRate, String fname, String lname, double salary, double savings, String prefType, String prefLoc, double price) {
        super(fname, lname, salary, savings, prefType, prefLoc, price);
        this.rentRate = rentRate;
    }

    public double getRentRate() {
        return rentRate;
    }

    public void setRentRate(double rentRate) {
        this.rentRate = rentRate;
    }

    public void computeRent() {
        if (prefType.equalsIgnoreCase("apartment")){
            typeRate = 0.8;
        }
        else if (prefType.equalsIgnoreCase("detatched house")){
            typeRate = 1.3;
        }
        else if (prefType.equalsIgnoreCase("bungalow")){
            typeRate = 1;
        }
        else if (prefType.equalsIgnoreCase("semi-detatched house")){
            typeRate = 1.1;
        }
        else if (prefType.equalsIgnoreCase("cottage")){
            typeRate = 0.9;
        }
        else if (prefType.equalsIgnoreCase("town house")){
            typeRate = 1.4;
        }
        else{
            JOptionPane.showMessageDialog(null, "Error: No house type selected.");
        }
        
        if ("dublin".equalsIgnoreCase(prefLoc)) {
            rentRate = 1550.00*typeRate;
        } else if ("waterford".equalsIgnoreCase(prefLoc)) {
            rentRate = 700.00*typeRate;
        } else if ("antrim".equalsIgnoreCase(prefLoc)) {
            rentRate = 1000.00*typeRate;
        } else if ("donegal".equalsIgnoreCase(prefLoc)) {
            rentRate = 675.00*typeRate;
        } else if ("galway".equalsIgnoreCase(prefLoc)) {
            rentRate = 1850.00*typeRate;
        } else if ("limerick".equalsIgnoreCase(prefLoc)) {
            rentRate = 960.00*typeRate;
        } else if ("kerry".equalsIgnoreCase(prefLoc)) {
            rentRate = 760.00*typeRate;
        } else if ("cork".equalsIgnoreCase(prefLoc)) {
            rentRate = 1160.00*typeRate;
        } else if ("leitrim".equalsIgnoreCase(prefLoc)) {
            rentRate = 525.00*typeRate;
        } else if ("clare".equalsIgnoreCase(prefLoc)) {
            rentRate = 720.00*typeRate;
        } else{
            JOptionPane.showMessageDialog(null,"Error: No location selected.");
        }
        d.setRent(rentRate);

    }
}
