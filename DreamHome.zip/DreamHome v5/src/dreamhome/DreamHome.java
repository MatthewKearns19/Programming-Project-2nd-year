
package dreamhome;

import java.io.Serializable;

/**
 * Project: DreamHome
 * @author Keith Mahony, Ben Carroll, Matthew Kearns
 * 
 */
public abstract class DreamHome implements Serializable{
    protected String fname;
    protected String lname;
    protected double salary;
    protected double savings;
    protected String prefType;
    protected String prefLoc;
    protected double price;
    protected double mgMonthly;
    protected double mgTotal;
    protected double rent;
    protected double timeToSave;
    protected double deposit;
    protected double savingsMonthly;
    
    DreamHome d;
    
    public DreamHome() {
        fname = " ";
        lname = " ";
        salary = 0.00;
        savings = 0.00;
        prefType = " ";
        prefLoc = " ";
        price = 0.00;
    }

    public DreamHome(String fname, String lname, double salary, double savings, String prefType, String prefLoc, double price) {
        this.fname = fname;
        this.lname = lname;
        this.salary = salary;
        this.savings = savings;
        this.prefType = prefType;
        this.prefLoc = prefLoc;
        this.price = price; 
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getPrefLoc() {
        return prefLoc;
    }

    public void setPrefLoc(String prefLoc) {
        this.prefLoc = prefLoc;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public double getSavings() {
        return savings;
    }

    public void setSavings(double savings) {
        this.savings = savings;
    }

    public String getPrefType() {
        return prefType;
    }

    public void setPrefType(String prefType) {
        this.prefType = prefType;
    }

    public double getMgMonthly() {
        return mgMonthly;
    }

    public void setMgMonthly(double mgMonthly) {
        this.mgMonthly = mgMonthly;
    }

    public double getMgTotal() {
        return mgTotal;
    }

    public void setMgTotal(double mgTotal) {
        this.mgTotal = mgTotal;
    }

    public double getRent() {
        return rent;
    }

    public void setRent(double rentRate) {
        this.rent = rentRate;
    }

    public double getTimeToSave() {
        return timeToSave;
    }

    public void setTimeToSave(double timeToSave) {
        this.timeToSave = timeToSave;
    }
    
    public void setDeposit(double deposit){
        this.deposit = deposit;
    }

    public double getDeposit() {
        return deposit;
    }

    public double getSavingsMonthly() {
        return savingsMonthly;
    }

    public void setSavingsMonthly(double SavingsMonthly) {
        this.savingsMonthly = SavingsMonthly;
    }

    public abstract void computeMortgage();
    
    public abstract void computeRent();
    
    public abstract void computeTimeToSave();

}
