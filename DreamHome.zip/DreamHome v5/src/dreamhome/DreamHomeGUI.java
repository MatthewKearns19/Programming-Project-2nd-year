package dreamhome;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 * Project: DreamHome
 *
 * @author Keith Mahony, Ben Carroll, Matthew Kearns
 *
 */
public class DreamHomeGUI extends javax.swing.JFrame {

    //Creating Array to store inputs across panels and count for identification
    //Count is not increased everytime data is input, only after final input on 'Save' jPanel
    //This keeps every run-through of app (and the data it creates) unique and saved separately:
    private ArrayList<DreamHome> dList;
    DreamHome d;
    int count;
    //Creating booleans to check and control users progress before saving
    boolean mortgageOption;
    boolean rentOption;
    boolean savingOption;

    public DreamHomeGUI() {
        dList = new ArrayList<>();
        count = 0;
        mortgageOption = false;
        rentOption = false;
        savingOption = false;

        //Below code gets around issue with GUI not casting to subclasses (Serialization)
        //Runs identical function from within GUI itself
        this.d = new DreamHome() {
            @Override
            public void computeMortgage() {
                //Calculates mortage by multiplying price of house(users choice) by average mortgage rates
                //Uses that to find total and monthly costs, rounds off usign Math.floor
                mgTotal = price * 1.51;
                mgMonthly = (mgTotal / 20) / 12;
                this.mgMonthly = Math.floor(mgMonthly);
                this.mgTotal = Math.floor(mgTotal);
                System.out.println(mgMonthly);
                System.out.println(mgTotal);
            }

            @Override
            public void computeTimeToSave() {
                double savingsMonthly = 0.0;

                double deposit = 0.0;
                double perSavings = perSavingsSlider.getValue();
                savingsMonthly = salary * (perSavings / 100.00);
                deposit = price * 0.2;
                timeToSave = Math.floor(deposit / savingsMonthly);

                this.timeToSave = timeToSave;
                this.deposit = deposit;
                this.savingsMonthly = savingsMonthly;
            }

            @Override
            public void computeRent() {
                //Increases or decreases average rental cost depending on type of house chosen
                double typeRate = 1.0;
                double rentRate = 1.0;
                if (prefType.equalsIgnoreCase("apartment")) {
                    typeRate = 0.8;
                } else if (prefType.equalsIgnoreCase("detatched house")) {
                    typeRate = 1.3;
                } else if (prefType.equalsIgnoreCase("bungalow")) {
                    typeRate = 1;
                } else if (prefType.equalsIgnoreCase("semi-detatched house")) {
                    typeRate = 1.1;
                } else if (prefType.equalsIgnoreCase("cottage")) {
                    typeRate = 0.9;
                } else if (prefType.equalsIgnoreCase("town house")) {
                    typeRate = 1.4;
                } else {
                    JOptionPane.showMessageDialog(null, "Error: No house type selected.");
                }

                if ("dublin".equalsIgnoreCase(prefLoc)) {
                    rentRate = Math.floor(1550.00 * typeRate);
                } else if ("waterford".equalsIgnoreCase(prefLoc)) {
                    rentRate = Math.floor(700.00 * typeRate);
                } else if ("antrim".equalsIgnoreCase(prefLoc)) {
                    rentRate = Math.floor(1000.00 * typeRate);
                } else if ("donegal".equalsIgnoreCase(prefLoc)) {
                    rentRate = Math.floor(675.00 * typeRate);
                } else if ("galway".equalsIgnoreCase(prefLoc)) {
                    rentRate = Math.floor(1850.00 * typeRate);
                } else if ("limerick".equalsIgnoreCase(prefLoc)) {
                    rentRate = Math.floor(960.00 * typeRate);
                } else if ("kerry".equalsIgnoreCase(prefLoc)) {
                    rentRate = Math.floor(760.00 * typeRate);
                } else if ("cork".equalsIgnoreCase(prefLoc)) {
                    rentRate = Math.floor(1160.00 * typeRate);
                } else if ("leitrim".equalsIgnoreCase(prefLoc)) {
                    rentRate = Math.floor(525.00 * typeRate);
                } else if ("clare".equalsIgnoreCase(prefLoc)) {
                    rentRate = Math.floor(720.00 * typeRate);
                } else {
                    JOptionPane.showMessageDialog(null, "Error: No location selected.");
                }

                this.rent = rentRate;
            }
        };
        initComponents();
        //hiding panels that are not being used
        locPanel.setVisible(false);
        incomePanel.setVisible(false);
        outputPanel.setVisible(false);
        savePanel.setVisible(false);
    }

    //Do NOT modify this code:
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField1 = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        topPanel = new javax.swing.JPanel();
        detatchedBtn = new javax.swing.JButton();
        bungalowBtn = new javax.swing.JButton();
        townBtn = new javax.swing.JButton();
        cottageBtn = new javax.swing.JButton();
        apartmentBtn = new javax.swing.JButton();
        semiBtn = new javax.swing.JButton();
        chooseLbl = new javax.swing.JLabel();
        loadBtn = new javax.swing.JButton();
        logo1Lbl = new javax.swing.JLabel();
        apartmentLbl = new javax.swing.JLabel();
        bungalowLbl = new javax.swing.JLabel();
        semiLbl = new javax.swing.JLabel();
        detachedLbl = new javax.swing.JLabel();
        cottageLbl = new javax.swing.JLabel();
        townLbl = new javax.swing.JLabel();
        locPanel = new javax.swing.JPanel();
        messageBtn = new javax.swing.JLabel();
        returnBtn = new javax.swing.JButton();
        dublinBtn = new javax.swing.JButton();
        waterfordBtn = new javax.swing.JButton();
        antrimBtn = new javax.swing.JButton();
        donegalBtn = new javax.swing.JButton();
        galwayBtn = new javax.swing.JButton();
        limerickBtn = new javax.swing.JButton();
        kerryBtn = new javax.swing.JButton();
        corkBtn = new javax.swing.JButton();
        leitrimBtn = new javax.swing.JButton();
        clareBtn = new javax.swing.JButton();
        logo2Lbl = new javax.swing.JLabel();
        incomePanel = new javax.swing.JPanel();
        messageLbl = new javax.swing.JLabel();
        salaryLbl = new javax.swing.JLabel();
        salaryTf = new javax.swing.JTextField();
        perSavingsSlider = new javax.swing.JSlider();
        savingsLbl = new javax.swing.JLabel();
        percentLbl = new javax.swing.JLabel();
        returnBtn1 = new javax.swing.JButton();
        submitBtn = new javax.swing.JButton();
        logo3Lbl = new javax.swing.JLabel();
        outputPanel = new javax.swing.JPanel();
        messageLbl1 = new javax.swing.JLabel();
        printMortgageBtn = new javax.swing.JButton();
        returnToIncomeBtn = new javax.swing.JButton();
        saveBtn = new javax.swing.JButton();
        printRentBtn = new javax.swing.JButton();
        printSavingBtn = new javax.swing.JButton();
        infoLbl1 = new javax.swing.JLabel();
        infoLbl2 = new javax.swing.JLabel();
        infoLbl3 = new javax.swing.JLabel();
        logo4Lbl = new javax.swing.JLabel();
        message2Lbl = new javax.swing.JLabel();
        confetti2Lbl = new javax.swing.JLabel();
        confettiLbl = new javax.swing.JLabel();
        savePanel = new javax.swing.JPanel();
        messageLbl2 = new javax.swing.JLabel();
        fnameLbl = new javax.swing.JLabel();
        lnameLbl = new javax.swing.JLabel();
        fnameTf = new javax.swing.JTextField();
        lnameTf = new javax.swing.JTextField();
        saveBtn1 = new javax.swing.JButton();
        cancelBtn = new javax.swing.JButton();
        logo5Lbl = new javax.swing.JLabel();

        jTextField1.setText("jTextField1");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        topPanel.setBackground(new java.awt.Color(255, 255, 255));
        topPanel.setMaximumSize(new java.awt.Dimension(150, 150));
        topPanel.setPreferredSize(new java.awt.Dimension(291, 152));
        topPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        detatchedBtn.setBackground(new java.awt.Color(0, 0, 0));
        detatchedBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dreamhome/detatched.jpg"))); // NOI18N
        detatchedBtn.setText("Detatched");
        detatchedBtn.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(0, 0, 0)));
        detatchedBtn.setMaximumSize(new java.awt.Dimension(150, 150));
        detatchedBtn.setPreferredSize(new java.awt.Dimension(291, 152));
        detatchedBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                detatchedBtnActionPerformed(evt);
            }
        });
        topPanel.add(detatchedBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 280, 175, 100));

        bungalowBtn.setBackground(new java.awt.Color(0, 0, 0));
        bungalowBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dreamhome/bungalow.jpg"))); // NOI18N
        bungalowBtn.setText("Bungalow");
        bungalowBtn.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(0, 0, 0)));
        bungalowBtn.setMaximumSize(new java.awt.Dimension(150, 150));
        bungalowBtn.setPreferredSize(new java.awt.Dimension(291, 152));
        bungalowBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bungalowBtnActionPerformed(evt);
            }
        });
        topPanel.add(bungalowBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 120, 175, 100));

        townBtn.setBackground(new java.awt.Color(0, 0, 0));
        townBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dreamhome/town.jpg"))); // NOI18N
        townBtn.setText("Town house");
        townBtn.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(0, 0, 0)));
        townBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                townBtnActionPerformed(evt);
            }
        });
        topPanel.add(townBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 280, 175, 100));

        cottageBtn.setBackground(new java.awt.Color(0, 0, 0));
        cottageBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dreamhome/cottage.jpg"))); // NOI18N
        cottageBtn.setText("Cottage");
        cottageBtn.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(0, 0, 0)));
        cottageBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cottageBtnActionPerformed(evt);
            }
        });
        topPanel.add(cottageBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 280, 175, 100));

        apartmentBtn.setBackground(new java.awt.Color(0, 0, 0));
        apartmentBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dreamhome/apartment.jpg"))); // NOI18N
        apartmentBtn.setText("Apartment");
        apartmentBtn.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(0, 0, 0)));
        apartmentBtn.setMaximumSize(new java.awt.Dimension(150, 150));
        apartmentBtn.setPreferredSize(new java.awt.Dimension(291, 152));
        apartmentBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                apartmentBtnActionPerformed(evt);
            }
        });
        topPanel.add(apartmentBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 120, 175, 100));

        semiBtn.setBackground(new java.awt.Color(0, 0, 0));
        semiBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dreamhome/semi.jpg"))); // NOI18N
        semiBtn.setText("Semi-detatched");
        semiBtn.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(0, 0, 0)));
        semiBtn.setMaximumSize(new java.awt.Dimension(150, 150));
        semiBtn.setMinimumSize(new java.awt.Dimension(240, 240));
        semiBtn.setPreferredSize(new java.awt.Dimension(291, 152));
        semiBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                semiBtnActionPerformed(evt);
            }
        });
        topPanel.add(semiBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 120, 175, 100));

        chooseLbl.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        chooseLbl.setText("Choose a house type:");
        topPanel.add(chooseLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 80, -1, -1));

        loadBtn.setBackground(new java.awt.Color(51, 153, 255));
        loadBtn.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        loadBtn.setForeground(new java.awt.Color(255, 255, 255));
        loadBtn.setText("Load Details");
        loadBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loadBtnActionPerformed(evt);
            }
        });
        topPanel.add(loadBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 440, -1, -1));

        logo1Lbl.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dreamhome/logo.png"))); // NOI18N
        logo1Lbl.setText("DreamHome1Lbl");
        topPanel.add(logo1Lbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 0, 440, 110));

        apartmentLbl.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        apartmentLbl.setText("Apartment");
        topPanel.add(apartmentLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 220, -1, 30));

        bungalowLbl.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        bungalowLbl.setText("Bungalow");
        topPanel.add(bungalowLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 220, -1, 30));

        semiLbl.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        semiLbl.setText("Semi-Detached");
        topPanel.add(semiLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 220, -1, 30));

        detachedLbl.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        detachedLbl.setText("Detached");
        topPanel.add(detachedLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 380, -1, 30));

        cottageLbl.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        cottageLbl.setText("Cottage");
        topPanel.add(cottageLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 380, -1, 30));

        townLbl.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        townLbl.setText("Town House");
        topPanel.add(townLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 380, -1, 30));

        locPanel.setBackground(new java.awt.Color(255, 255, 255));
        locPanel.setMinimumSize(new java.awt.Dimension(650, 500));
        locPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        messageBtn.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        messageBtn.setText("Choose a county:");
        locPanel.add(messageBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 80, -1, -1));

        returnBtn.setBackground(new java.awt.Color(255, 51, 51));
        returnBtn.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        returnBtn.setForeground(new java.awt.Color(255, 255, 255));
        returnBtn.setText("Return");
        returnBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                returnBtnActionPerformed(evt);
            }
        });
        locPanel.add(returnBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 450, -1, -1));

        dublinBtn.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        dublinBtn.setText("Dublin");
        dublinBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dublinBtnActionPerformed(evt);
            }
        });
        locPanel.add(dublinBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 120, 100, -1));

        waterfordBtn.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        waterfordBtn.setText("Waterford");
        waterfordBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                waterfordBtnActionPerformed(evt);
            }
        });
        locPanel.add(waterfordBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 120, 120, -1));

        antrimBtn.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        antrimBtn.setText("Antrim");
        antrimBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                antrimBtnActionPerformed(evt);
            }
        });
        locPanel.add(antrimBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 360, 100, -1));

        donegalBtn.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        donegalBtn.setText("Donegal");
        donegalBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                donegalBtnActionPerformed(evt);
            }
        });
        locPanel.add(donegalBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 240, 100, -1));

        galwayBtn.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        galwayBtn.setText("Galway");
        galwayBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                galwayBtnActionPerformed(evt);
            }
        });
        locPanel.add(galwayBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 180, 100, -1));

        limerickBtn.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        limerickBtn.setText("Limerick");
        limerickBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                limerickBtnActionPerformed(evt);
            }
        });
        locPanel.add(limerickBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 300, 100, -1));

        kerryBtn.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        kerryBtn.setText("Kerry");
        kerryBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kerryBtnActionPerformed(evt);
            }
        });
        locPanel.add(kerryBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 240, 100, -1));

        corkBtn.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        corkBtn.setText("Cork");
        corkBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                corkBtnActionPerformed(evt);
            }
        });
        locPanel.add(corkBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 300, 100, -1));

        leitrimBtn.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        leitrimBtn.setText("Leitrim");
        leitrimBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                leitrimBtnActionPerformed(evt);
            }
        });
        locPanel.add(leitrimBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 180, 100, -1));

        clareBtn.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        clareBtn.setText("Clare");
        clareBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clareBtnActionPerformed(evt);
            }
        });
        locPanel.add(clareBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 360, 100, -1));

        logo2Lbl.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dreamhome/logo.png"))); // NOI18N
        logo2Lbl.setText("DreamHome2Lbl");
        locPanel.add(logo2Lbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 0, 450, 110));

        incomePanel.setBackground(new java.awt.Color(255, 255, 255));
        incomePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        messageLbl.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        messageLbl.setText("Tell us about yourself:");
        incomePanel.add(messageLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 80, -1, -1));

        salaryLbl.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        salaryLbl.setText("Enter your annual take-home salary:");
        incomePanel.add(salaryLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, -1, 30));

        salaryTf.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        salaryTf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                salaryTfActionPerformed(evt);
            }
        });
        incomePanel.add(salaryTf, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 160, 260, 30));

        perSavingsSlider.setBackground(new java.awt.Color(255, 255, 255));
        perSavingsSlider.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        perSavingsSlider.setMajorTickSpacing(5);
        perSavingsSlider.setPaintLabels(true);
        perSavingsSlider.setPaintTicks(true);
        perSavingsSlider.setSnapToTicks(true);
        perSavingsSlider.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(0, 0, 0), new java.awt.Color(0, 0, 0)));
        perSavingsSlider.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                perSavingsSliderStateChanged(evt);
            }
        });
        incomePanel.add(perSavingsSlider, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 240, 530, 70));

        savingsLbl.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        savingsLbl.setText("How much of your salary you can save:");
        incomePanel.add(savingsLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, 430, -1));

        percentLbl.setFont(new java.awt.Font("Tahoma", 2, 16)); // NOI18N
        percentLbl.setText("%");
        incomePanel.add(percentLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 270, 40, 40));

        returnBtn1.setBackground(new java.awt.Color(255, 51, 51));
        returnBtn1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        returnBtn1.setForeground(new java.awt.Color(255, 255, 255));
        returnBtn1.setText("Return");
        returnBtn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                returnBtn1ActionPerformed(evt);
            }
        });
        incomePanel.add(returnBtn1, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 380, -1, -1));

        submitBtn.setBackground(new java.awt.Color(51, 255, 51));
        submitBtn.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        submitBtn.setForeground(new java.awt.Color(255, 255, 255));
        submitBtn.setText("Submit");
        submitBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitBtnActionPerformed(evt);
            }
        });
        incomePanel.add(submitBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 380, -1, -1));

        logo3Lbl.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dreamhome/logo.png"))); // NOI18N
        logo3Lbl.setText("DreamHome3Lbl");
        incomePanel.add(logo3Lbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 0, 440, 110));

        outputPanel.setBackground(new java.awt.Color(255, 255, 255));

        messageLbl1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        messageLbl1.setText("You're on your way to owning or renting your very own property!");

        printMortgageBtn.setBackground(new java.awt.Color(255, 255, 255));
        printMortgageBtn.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        printMortgageBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dreamhome/mortgage1.png"))); // NOI18N
        printMortgageBtn.setText("    Cost with a mortgage");
        printMortgageBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printMortgageBtnActionPerformed(evt);
            }
        });

        returnToIncomeBtn.setBackground(new java.awt.Color(255, 51, 51));
        returnToIncomeBtn.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        returnToIncomeBtn.setForeground(new java.awt.Color(255, 255, 255));
        returnToIncomeBtn.setText("Return");
        returnToIncomeBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                returnToIncomeBtnActionPerformed(evt);
            }
        });

        saveBtn.setBackground(new java.awt.Color(51, 255, 51));
        saveBtn.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        saveBtn.setForeground(new java.awt.Color(255, 255, 255));
        saveBtn.setText("Save Details");
        saveBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveBtnActionPerformed(evt);
            }
        });

        printRentBtn.setBackground(new java.awt.Color(255, 255, 255));
        printRentBtn.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        printRentBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dreamhome/rent1.png"))); // NOI18N
        printRentBtn.setText(" Rental cost of this property");
        printRentBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printRentBtnActionPerformed(evt);
            }
        });

        printSavingBtn.setBackground(new java.awt.Color(255, 255, 255));
        printSavingBtn.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        printSavingBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dreamhome/timetosave1.png"))); // NOI18N
        printSavingBtn.setText(" Time to save for a deposit");
        printSavingBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printSavingBtnActionPerformed(evt);
            }
        });

        infoLbl1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        infoLbl1.setText("We won't share your data with any potential third parties.");

        infoLbl2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        infoLbl2.setText("Even the ones willing to pay really well for your information.");

        infoLbl3.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        infoLbl3.setText("You can trust us!");

        logo4Lbl.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dreamhome/logo.png"))); // NOI18N
        logo4Lbl.setText("DreamHome4Lbl");

        message2Lbl.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        message2Lbl.setText("Congratulations!");

        confetti2Lbl.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dreamhome/confetti2.gif"))); // NOI18N
        confetti2Lbl.setText("confetti2Lbl");

        confettiLbl.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dreamhome/confettiw.gif"))); // NOI18N
        confettiLbl.setText("confettiLbl");

        javax.swing.GroupLayout outputPanelLayout = new javax.swing.GroupLayout(outputPanel);
        outputPanel.setLayout(outputPanelLayout);
        outputPanelLayout.setHorizontalGroup(
            outputPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(outputPanelLayout.createSequentialGroup()
                .addComponent(confetti2Lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(outputPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(printMortgageBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(printRentBtn, javax.swing.GroupLayout.DEFAULT_SIZE, 325, Short.MAX_VALUE)
                    .addComponent(printSavingBtn, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(confettiLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(outputPanelLayout.createSequentialGroup()
                .addGroup(outputPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(outputPanelLayout.createSequentialGroup()
                        .addGap(251, 251, 251)
                        .addComponent(message2Lbl))
                    .addGroup(outputPanelLayout.createSequentialGroup()
                        .addGap(110, 110, 110)
                        .addComponent(logo4Lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 445, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(outputPanelLayout.createSequentialGroup()
                        .addGap(54, 54, 54)
                        .addComponent(messageLbl1))
                    .addGroup(outputPanelLayout.createSequentialGroup()
                        .addGap(139, 139, 139)
                        .addComponent(saveBtn)
                        .addGap(123, 123, 123)
                        .addComponent(returnToIncomeBtn))
                    .addGroup(outputPanelLayout.createSequentialGroup()
                        .addGap(276, 276, 276)
                        .addComponent(infoLbl3)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, outputPanelLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(outputPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(infoLbl2)
                    .addComponent(infoLbl1, javax.swing.GroupLayout.PREFERRED_SIZE, 287, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(189, 189, 189))
        );
        outputPanelLayout.setVerticalGroup(
            outputPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(outputPanelLayout.createSequentialGroup()
                .addComponent(logo4Lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(9, 9, 9)
                .addComponent(message2Lbl)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(messageLbl1)
                .addGap(18, 18, 18)
                .addGroup(outputPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(outputPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(confettiLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(confetti2Lbl))
                    .addGroup(outputPanelLayout.createSequentialGroup()
                        .addComponent(printSavingBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(printMortgageBtn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(printRentBtn)))
                .addGap(63, 63, 63)
                .addGroup(outputPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(saveBtn)
                    .addComponent(returnToIncomeBtn, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(outputPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, outputPanelLayout.createSequentialGroup()
                        .addComponent(infoLbl1, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(31, 31, 31))
                    .addComponent(infoLbl2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(infoLbl3, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        savePanel.setBackground(new java.awt.Color(255, 255, 255));
        savePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        messageLbl2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        messageLbl2.setText("Enter your details to save:");
        savePanel.add(messageLbl2, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 80, -1, -1));

        fnameLbl.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        fnameLbl.setText("First Name:");
        savePanel.add(fnameLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 140, -1, -1));

        lnameLbl.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lnameLbl.setText("Last Name:");
        savePanel.add(lnameLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 190, -1, -1));

        fnameTf.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        fnameTf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fnameTfActionPerformed(evt);
            }
        });
        savePanel.add(fnameTf, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 130, 220, 30));

        lnameTf.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        savePanel.add(lnameTf, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 190, 220, -1));

        saveBtn1.setBackground(new java.awt.Color(51, 255, 51));
        saveBtn1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        saveBtn1.setForeground(new java.awt.Color(255, 255, 255));
        saveBtn1.setText("Save");
        saveBtn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveBtn1ActionPerformed(evt);
            }
        });
        savePanel.add(saveBtn1, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 290, -1, -1));

        cancelBtn.setBackground(new java.awt.Color(255, 51, 51));
        cancelBtn.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        cancelBtn.setForeground(new java.awt.Color(255, 255, 255));
        cancelBtn.setText("Cancel");
        cancelBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelBtnActionPerformed(evt);
            }
        });
        savePanel.add(cancelBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 290, -1, -1));

        logo5Lbl.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dreamhome/logo.png"))); // NOI18N
        logo5Lbl.setText("DreamHome5Lbl");
        savePanel.add(logo5Lbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 0, 440, 110));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(topPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 681, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(locPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 661, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 25, Short.MAX_VALUE)
                    .addComponent(incomePanel, javax.swing.GroupLayout.PREFERRED_SIZE, 630, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 26, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(outputPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(savePanel, javax.swing.GroupLayout.PREFERRED_SIZE, 650, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(21, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(topPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 610, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(locPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 588, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 40, Short.MAX_VALUE)
                    .addComponent(incomePanel, javax.swing.GroupLayout.PREFERRED_SIZE, 530, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 40, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(outputPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(15, 15, 15)
                    .addComponent(savePanel, javax.swing.GroupLayout.PREFERRED_SIZE, 500, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(95, Short.MAX_VALUE)))
        );

        java.awt.Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        setBounds((screenSize.width-686)/2, (screenSize.height-569)/2, 686, 569);
    }// </editor-fold>//GEN-END:initComponents

    private void detatchedBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_detatchedBtnActionPerformed
        // Sets users preffered type and price as detatched
        // Resets option booleans so user must complete all forms
        // displays location panel:
        d.setPrefType("Detatched house");
        d.setPrice(415000.00);
        topPanel.setVisible(false);
        locPanel.setVisible(true);
        dList.add(d);
        mortgageOption = false;
        rentOption = false;
        savingOption = false;
    }//GEN-LAST:event_detatchedBtnActionPerformed

    private void bungalowBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bungalowBtnActionPerformed
        // Sets users preffered type and price as bungalow
        // Resets option booleans so user must complete all forms
        // displays location panel:
        d.setPrefType("Bungalow");
        d.setPrice(365000.00);
        topPanel.setVisible(false);
        locPanel.setVisible(true);
        dList.add(d);
        mortgageOption = false;
        rentOption = false;
        savingOption = false;
    }//GEN-LAST:event_bungalowBtnActionPerformed

    private void apartmentBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_apartmentBtnActionPerformed
        // Sets users preffered type and price as apartment
        // Resets option booleans so user must complete all forms
        // displays location panel:
        d.setPrefType("apartment");
        d.setPrice(210000.00);
        topPanel.setVisible(false);
        locPanel.setVisible(true);
        dList.add(d);
        mortgageOption = false;
        rentOption = false;
        savingOption = false;
    }//GEN-LAST:event_apartmentBtnActionPerformed

    private void loadBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loadBtnActionPerformed
        // Displays users records on file(User_Information.txt stored in project folder):
        String record;
        File inFile;
        FileReader fr;
        BufferedReader br;

        try {
            inFile = new File("User_Information.txt");
            fr = new FileReader(inFile);
            br = new BufferedReader(fr);

            record = br.readLine();
            while (record != null) {

                JOptionPane.showMessageDialog(null, "Record: " + record);
                record = br.readLine();
            }
            br.close();
        } catch (IOException e) {
            System.out.println("Error:" + e);

        }
    }//GEN-LAST:event_loadBtnActionPerformed

    private void semiBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_semiBtnActionPerformed
        // Sets users preffered type and price as semi-detatched house
        // Resets option booleans so user must complete all forms (again) before saving data
        // displays location panel:
        d.setPrefType("semi-Detatched house");
        d.setPrice(380000.00);
        topPanel.setVisible(false);
        locPanel.setVisible(true);
        dList.add(d);
        mortgageOption = false;
        rentOption = false;
        savingOption = false;
    }//GEN-LAST:event_semiBtnActionPerformed

    private void cottageBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cottageBtnActionPerformed
        // Sets users preffered type and price as cottage
        // Resets option booleans so user must complete all forms 
        // displays location panel:
        d.setPrefType("Cottage");
        d.setPrice(300000.00);
        topPanel.setVisible(false);
        locPanel.setVisible(true);
        dList.add(d);
        mortgageOption = false;
        rentOption = false;
        savingOption = false;
    }//GEN-LAST:event_cottageBtnActionPerformed

    private void townBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_townBtnActionPerformed
        // Sets users preffered type and price as town house
        // Resets option booleans so user must complete all forms
        // displays location panel:
        d.setPrefType("Town house");
        d.setPrice(390000.00);
        topPanel.setVisible(false);
        locPanel.setVisible(true);
        dList.add(d);
        mortgageOption = false;
        rentOption = false;
        savingOption = false;
    }//GEN-LAST:event_townBtnActionPerformed

    private void returnBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_returnBtnActionPerformed
        // returns to topPanel:
        topPanel.setVisible(true);
        locPanel.setVisible(false);
    }//GEN-LAST:event_returnBtnActionPerformed

    private void dublinBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dublinBtnActionPerformed
        // Sets preffered location as Dublin
        // Displays income panel:
        d.setPrefLoc("Dublin");
        locPanel.setVisible(false);
        incomePanel.setVisible(true);
        dList.add(d);
    }//GEN-LAST:event_dublinBtnActionPerformed

    private void waterfordBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_waterfordBtnActionPerformed
        // Sets preffered location as Waterford
        // Displays income panel:
        d.setPrefLoc("Waterford");
        locPanel.setVisible(false);
        incomePanel.setVisible(true);
        dList.add(d);
    }//GEN-LAST:event_waterfordBtnActionPerformed

    private void antrimBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_antrimBtnActionPerformed
        // Sets preffered location as Antrim
        // Displays income panel:
        d.setPrefLoc("Antrim");
        locPanel.setVisible(false);
        incomePanel.setVisible(true);
        dList.add(d);
    }//GEN-LAST:event_antrimBtnActionPerformed

    private void donegalBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_donegalBtnActionPerformed
        // Sets preffered location as Donegal
        // Displays income panel:
        d.setPrefLoc("Donegal");
        locPanel.setVisible(false);
        incomePanel.setVisible(true);
        dList.add(d);
    }//GEN-LAST:event_donegalBtnActionPerformed

    private void galwayBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_galwayBtnActionPerformed
        // Sets preffered location as Galway
        // Displays income panel:
        d.setPrefLoc("Galway");
        locPanel.setVisible(false);
        incomePanel.setVisible(true);
        dList.add(d);
    }//GEN-LAST:event_galwayBtnActionPerformed

    private void limerickBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_limerickBtnActionPerformed
        // Sets preffered location as Limerick
        // Displays income panel:
        d.setPrefLoc("Limerick");
        locPanel.setVisible(false);
        incomePanel.setVisible(true);
        dList.add(d);
    }//GEN-LAST:event_limerickBtnActionPerformed

    private void kerryBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kerryBtnActionPerformed
        // Sets preffered location as kerry
        // Displays income panel:
        d.setPrefLoc("Kerry");
        locPanel.setVisible(false);
        incomePanel.setVisible(true);
        dList.add(d);
    }//GEN-LAST:event_kerryBtnActionPerformed

    private void corkBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_corkBtnActionPerformed
        // Sets preffered location as Cork
        // Displays income panel:
        d.setPrefLoc("Cork");
        locPanel.setVisible(false);
        incomePanel.setVisible(true);
        dList.add(d);
    }//GEN-LAST:event_corkBtnActionPerformed

    private void leitrimBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_leitrimBtnActionPerformed
        // Sets preffered location as Leitrim
        // Displays income panel:
        d.setPrefLoc("Leitrim");
        locPanel.setVisible(false);
        incomePanel.setVisible(true);
        dList.add(d);
    }//GEN-LAST:event_leitrimBtnActionPerformed

    private void clareBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clareBtnActionPerformed
        // Sets preffered location as Clare
        // Displays income panel:
        d.setPrefLoc("Clare");
        locPanel.setVisible(false);
        incomePanel.setVisible(true);
        dList.add(d);
    }//GEN-LAST:event_clareBtnActionPerformed

    private void salaryTfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_salaryTfActionPerformed
        //No functionality here
    }//GEN-LAST:event_salaryTfActionPerformed

    private void returnBtn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_returnBtn1ActionPerformed
        // Displays Location panel:
        locPanel.setVisible(true);
        incomePanel.setVisible(false);
    }//GEN-LAST:event_returnBtn1ActionPerformed

    private void submitBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitBtnActionPerformed
        // tries to grab salaryTf input and store in DreamHome.java
        // if field is empty or not a suitable variable it feeds error message to user

        try {
            double salary = Double.parseDouble(salaryTf.getText());
            d.setSalary(salary);
            double perSavings = perSavingsSlider.getValue();
            incomePanel.setVisible(false);
            outputPanel.setVisible(true);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Please enter your salary. It's really important to us. And your future.");
        }

    }//GEN-LAST:event_submitBtnActionPerformed

    private void printMortgageBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printMortgageBtnActionPerformed
        /*Cannot cast from GUI to Mortgage.java so this method won't work
         double monthlyPrice10 = ((Mortgage)d).getMonthlyPrice10();
         double monthlyPrice20 = ((Mortgage)d).getMonthlyPrice20();
         double mortgageTotalPayback10 = ((Mortgage)d).getMortgageTotalPayback10(); 
         double mortgageTotalPayback20 = ((Mortgage)d).getMortgageTotalPayback10();
         */

        // Prints mortgage details to screen using function from Mortgage.java:
        d.computeMortgage();

        //getting variables
        double mgMonthly = d.getMgMonthly();
        double price = d.getPrice();
        double mgTotal = d.getMgTotal();

        //Outputs messsage with house price, monthly and total cost:
        JOptionPane.showMessageDialog(null, "Congratulations! \nThat property will only cost you " + price + ". \nFor the low, low price of " + mgMonthly + " a month to take out a 20 year mortgage on it, it's yours. \nComing to the very reasonable total cost of  " + mgTotal + ".");
        mortgageOption = true;
    }//GEN-LAST:event_printMortgageBtnActionPerformed

    private void returnToIncomeBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_returnToIncomeBtnActionPerformed
        // Displays Income panel:
        incomePanel.setVisible(true);
        outputPanel.setVisible(false);
    }//GEN-LAST:event_returnToIncomeBtnActionPerformed

    private void saveBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveBtnActionPerformed
        // Displays 'Save' jPanel:
        if (mortgageOption == true && rentOption == true && savingOption == true) {
            savePanel.setVisible(true);
            outputPanel.setVisible(false);
        } else if (mortgageOption == false && rentOption == true && savingOption == true) {
            JOptionPane.showMessageDialog(null, "You still need to calculate your mortgage.");
        } else if (mortgageOption == true && rentOption == false && savingOption == true) {
            JOptionPane.showMessageDialog(null, "You still need to calculate your rent.");
        } else if (mortgageOption == true && rentOption == false && savingOption == false) {
            JOptionPane.showMessageDialog(null, "You still need to calculate your rent and time to save.");
        } else if (mortgageOption == false && rentOption == true && savingOption == false) {
            JOptionPane.showMessageDialog(null, "You still need to calculate your mortage and time to save.");
        } else if (mortgageOption == false && rentOption == false && savingOption == true) {
            JOptionPane.showMessageDialog(null, "You still need to calculate your mortage and rent.");
        } else if (mortgageOption == true && rentOption == true && savingOption == false) {
            JOptionPane.showMessageDialog(null, "You still need to calculate your time to save.");
        }else {
            JOptionPane.showMessageDialog(null, "You have no caluculations to save.");
        }
    }//GEN-LAST:event_saveBtnActionPerformed
    private void fnameTfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fnameTfActionPerformed
        // No functionality here:
    }//GEN-LAST:event_fnameTfActionPerformed

    private void saveBtn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveBtn1ActionPerformed
        // Grabs user details, stores them in a file 'UserInformation.txt':

        File outFile;
        FileWriter fw;
        BufferedWriter bw;

        String fname = fnameTf.getText();
        String lname = lnameTf.getText();
        String prefType = d.getPrefType();
        String prefLoc = d.getPrefLoc();
        double rent = dList.get(count).getRent();
        double mgMonthly = d.getMgMonthly();

        try {
            outFile = new File("User_Information.txt");
            fw = new FileWriter(outFile, true);
            bw = new BufferedWriter(fw);

            bw.write("First Name: " + fname + ". Last Name: " + lname + ". Type: " + prefType + ". Location:" + prefLoc + ". Rent Rate:" + rent + ". Mortgage Repayments: " + mgMonthly);
            bw.newLine();
            bw.close();
            JOptionPane.showMessageDialog(null, "Information saved correctly.");
        } catch (IOException e) {
            System.out.println("Error: " + e);
        }
        //Displays topPanel:
        savePanel.setVisible(false);
        topPanel.setVisible(true);
        count++;
    }//GEN-LAST:event_saveBtn1ActionPerformed

    private void cancelBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelBtnActionPerformed
        // Displays output jPanel:
        savePanel.setVisible(false);
        outputPanel.setVisible(true);
    }//GEN-LAST:event_cancelBtnActionPerformed

    private void printRentBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printRentBtnActionPerformed
        // Computes and displays Rent details specific to user:
        d.computeRent();
        double rent = dList.get(count).getRent();
        String prefType = dList.get(count).getPrefType();
        String prefLoc = d.getPrefLoc();
        JOptionPane.showMessageDialog(null, "Congratulations! \nFor the low, low cost of " + rent + " a month, you can rent your very own " + prefType + " in " + prefLoc + ".");
        rentOption = true;
    }//GEN-LAST:event_printRentBtnActionPerformed

    private void printSavingBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printSavingBtnActionPerformed
        // Prints saving details to user via JOptionPane:
        d.computeTimeToSave();
        savingOption = true;
        double timeToSave = d.getTimeToSave();
        double savingsMonthly = dList.get(count).getSavingsMonthly();
        double deposit = dList.get(count).getDeposit();
        JOptionPane.showMessageDialog(null, "Congratulations! \nEven with annual savings of " + savingsMonthly + ",  it'll still take you " + timeToSave + " months to save for your mortgage deposit, which will come to a total of " + deposit + ".");
        
    }//GEN-LAST:event_printSavingBtnActionPerformed

    private void perSavingsSliderStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_perSavingsSliderStateChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_perSavingsSliderStateChanged

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;


                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DreamHomeGUI.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DreamHomeGUI.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DreamHomeGUI.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DreamHomeGUI.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DreamHomeGUI().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton antrimBtn;
    private javax.swing.JButton apartmentBtn;
    private javax.swing.JLabel apartmentLbl;
    private javax.swing.JButton bungalowBtn;
    private javax.swing.JLabel bungalowLbl;
    private javax.swing.JButton cancelBtn;
    private javax.swing.JLabel chooseLbl;
    private javax.swing.JButton clareBtn;
    private javax.swing.JLabel confetti2Lbl;
    private javax.swing.JLabel confettiLbl;
    private javax.swing.JButton corkBtn;
    private javax.swing.JButton cottageBtn;
    private javax.swing.JLabel cottageLbl;
    private javax.swing.JLabel detachedLbl;
    private javax.swing.JButton detatchedBtn;
    private javax.swing.JButton donegalBtn;
    private javax.swing.JButton dublinBtn;
    private javax.swing.JLabel fnameLbl;
    private javax.swing.JTextField fnameTf;
    private javax.swing.JButton galwayBtn;
    private javax.swing.JPanel incomePanel;
    private javax.swing.JLabel infoLbl1;
    private javax.swing.JLabel infoLbl2;
    private javax.swing.JLabel infoLbl3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JButton kerryBtn;
    private javax.swing.JButton leitrimBtn;
    private javax.swing.JButton limerickBtn;
    private javax.swing.JLabel lnameLbl;
    private javax.swing.JTextField lnameTf;
    private javax.swing.JButton loadBtn;
    private javax.swing.JPanel locPanel;
    private javax.swing.JLabel logo1Lbl;
    private javax.swing.JLabel logo2Lbl;
    private javax.swing.JLabel logo3Lbl;
    private javax.swing.JLabel logo4Lbl;
    private javax.swing.JLabel logo5Lbl;
    private javax.swing.JLabel message2Lbl;
    private javax.swing.JLabel messageBtn;
    private javax.swing.JLabel messageLbl;
    private javax.swing.JLabel messageLbl1;
    private javax.swing.JLabel messageLbl2;
    private javax.swing.JPanel outputPanel;
    private javax.swing.JSlider perSavingsSlider;
    private javax.swing.JLabel percentLbl;
    private javax.swing.JButton printMortgageBtn;
    private javax.swing.JButton printRentBtn;
    private javax.swing.JButton printSavingBtn;
    private javax.swing.JButton returnBtn;
    private javax.swing.JButton returnBtn1;
    private javax.swing.JButton returnToIncomeBtn;
    private javax.swing.JLabel salaryLbl;
    private javax.swing.JTextField salaryTf;
    private javax.swing.JButton saveBtn;
    private javax.swing.JButton saveBtn1;
    private javax.swing.JPanel savePanel;
    private javax.swing.JLabel savingsLbl;
    private javax.swing.JButton semiBtn;
    private javax.swing.JLabel semiLbl;
    private javax.swing.JButton submitBtn;
    private javax.swing.JPanel topPanel;
    private javax.swing.JButton townBtn;
    private javax.swing.JLabel townLbl;
    private javax.swing.JButton waterfordBtn;
    // End of variables declaration//GEN-END:variables
}
