
package dreamhome;

import java.io.Serializable;
import javax.swing.JOptionPane;

/**
 *
 * @author Matthew Kearns, Ben Carroll, Keith Mahony
 */
public abstract class Mortgage extends DreamHome implements Serializable{ 
    
    public double mgTotal;
    public double monthlyPrice;

    public Mortgage(double totalPayback, double monthlyPrice) {
        this.mgTotal = totalPayback;
        this.monthlyPrice = monthlyPrice;
    }

    public Mortgage(double totalPayback, double monthlyPrice, String fname, String lname, double salary, double savings, String prefType, String prefLoc, double price) {
        super(fname, lname, salary, savings, prefType, prefLoc, price);
        this.mgTotal = totalPayback;
        this.monthlyPrice = monthlyPrice;
    }

    @Override
    public void computeMortgage(){
        double price = d.getPrice();
        mgTotal = price*1.51;
        mgMonthly = (mgTotal/20)/12;
        d.setMgMonthly(mgMonthly);
        d.setMgTotal(mgTotal);
        System.out.println(mgMonthly);
        System.out.println(mgTotal);
        
    }

    public double getMgTotal() {
        return mgTotal;
    }

    public void setMgTotal(double mgTotal) {
        this.mgTotal = mgTotal;
    }

    public double getMonthlyPrice() {
        return monthlyPrice;
    }

    public void setMonthlyPrice(double monthlyPrice) {
        this.monthlyPrice = monthlyPrice;
    }

    
    
}



