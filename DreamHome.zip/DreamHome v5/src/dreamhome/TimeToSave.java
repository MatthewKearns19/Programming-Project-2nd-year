/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dreamhome;

import java.io.Serializable;

/**
 *
 * @author Ben Carroll, Keith Mahony, Matthew Kearns
 */
public abstract class TimeToSave extends DreamHome implements Serializable{
    public double perSavings;
    public double savingsMonthly;
    public double deposit;

    public TimeToSave(double perSavings, double savingsMonthly, double deposit) {
        this.perSavings = perSavings;
        this.savingsMonthly = savingsMonthly;
        this.deposit = deposit;
    }

    public TimeToSave(double perSavings, double savingsMonthly, double deposit, String fname, String lname, double salary, double savings, String prefType, String prefLoc, double price) {
        super(fname, lname, salary, savings, prefType, prefLoc, price);
        this.perSavings = perSavings;
        this.savingsMonthly = savingsMonthly;
        this.deposit = deposit;
    }
    public double getMonthlyPerSavings(){
        return perSavings;
    }

    public double getDeposit() {
        return deposit;
    }

    public void setDeposit(double deposit) {
        this.deposit = deposit;
    }

    public void setMonthlyPerSavings(double monthlyPerSavings) {
        this.perSavings = perSavings;
    }
    
    public void computeTimeToSave(){
        savingsMonthly=salary*(perSavings/100);
        deposit=price*0.2;
        timeToSave=deposit/savingsMonthly;

       d.setTimeToSave(timeToSave);
    }
}
