
package dreamhome;

/**
 * Project: DreamHome
 * @author Keith Mahony, Ben Carroll, Matthew Kearns
 */
public class DreamHomeApp {

    public static void main(String[] args) {
        // TODO code application logic her
        DreamHomeGUI topGUI = new DreamHomeGUI();
        topGUI.setVisible(true);  
    }
    
}
